defmodule Foo do
  def foo do
    "bye world"
  end
end
